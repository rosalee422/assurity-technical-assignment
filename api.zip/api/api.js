//
// **** Assurity Technical Assignment  ****
//
// *** Acceptance Criteria: ***
// 1. Name = "Badges"
// 2. CanRelist = true
// 3. The Promotions element with Name = "Feature" has a Description that contains the text "Better position in category"

describe('Assurity Technical Assignment', () => {
  const api = 'https://api.tmsandbox.co.nz/v1/Categories/6328/Details.json?catalogue=false'

  it('Returns JSON', () => {
    cy.request(api)
      .its('headers')
      .its('content-type')
      .should('include', 'application/json')
  })

  it('Returns 200 response code', function () {
    cy.request(api)
      .its('status')
      .should('equal', 200)
  })

  it('1: Element "Name" is equal to "Badges"', function () {
    cy.request(api)
      .should(function (response) {
        expect(response.body).to.have.property('Name', 'Badges')
      })
  })

  it('2: Element "CanRelist" is equal to "true"', function () {
    cy.request(api)
      .should(function (response) {
        expect(response.body).to.have.property('CanRelist', true)
      })
  })

  it('3: Promotions element with Name "Feature", has a Description that contains the text "Better position in category"', function () {
    const getPromo = () => cy.request(api).its('body').its('Promotions')

    getPromo().each(function($element) {
      for(var key in $element) {
        if ($element.hasOwnProperty(key)) {
          if ($element[key] == 'Feature') {
            expect($element).to.have.property('Description').contains('Better position in category')
          }
        }
      }
    })
  })
})
